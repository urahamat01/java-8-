// (Display five messages) Write a program that displays Welcome to Java five times.
public class Exercise_01_02 {
	public static void main(String[] args) {
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Java.");
	}
}
