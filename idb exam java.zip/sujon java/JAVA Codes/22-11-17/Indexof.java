public class Indexof{
	public static void main(String[] args){
		String s1 = "Bangladesh ";
		int x = s1.indexOf("n");
		System.out.println(x);
	}
}