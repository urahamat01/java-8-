public class ArrayTest{
	public static void main(String[] args){
		String a[] = {"Arif","Monirul","Johra","Rakib","Jafar","Aflatul","Sawkat","Tania","Sarwar","Rezaul"};
		
		for(int i=0; i<a.length; i++){
			System.out.println(a[i]);
		}
	}
}