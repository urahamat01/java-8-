public class TrimTest{
	public static void main(String[] args){
		String s = "Arif ";
		String r = s.trim();
		System.out.println("Length of Arif before trim: "+s.length());
		System.out.println("Length of Arif after trim: "+r.length());
	}
}