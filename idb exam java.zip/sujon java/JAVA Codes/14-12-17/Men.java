//Abstract class for Student
import java.io.*;
public abstract class Men implements Serializable{
	public String name;
	public String gender;
	int nid;
}