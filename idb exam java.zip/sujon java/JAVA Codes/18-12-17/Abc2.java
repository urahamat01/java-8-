public interface Abc2{
	public abstract int m1();
	public abstract String m2();
	public abstract void m3();
}