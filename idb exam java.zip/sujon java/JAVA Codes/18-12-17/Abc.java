public interface Abc{
	public abstract int m1();
}