public class Student{
	public static void main(String[] args){
		
		System.out.println("Hello Bangladesh!");
	}
}