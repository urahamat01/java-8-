//Main class
public class TestPolymorphism{
	public static void main(String[] args){
		Animal a = new Cow();
		System.out.println(a.eat());
	}
}