//Parent class
public class Animal{
	public String eat(){
		return "food";
	}
}