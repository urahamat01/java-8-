//Child class of Animal
public class Men extends Animal{
	public String eat(){
		return "rice";
	}
}