//Child class of Animal
public class Cow extends Animal{
	public String eat(){
		return "grass";
	}
}