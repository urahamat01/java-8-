public class DeclaringArray{
	public static void main(String[] args){
		int[] i = new int[5];
		i[0] = 5;
		i[1] = 10;
		i[2] = 20;
		String[] s = new String[20];
		s[0] = "Monirul";
		s[1] = "Islam";
		s[3] = "Ariful";
		s[4] = "Islam";
		System.out.println(s[0]);
	}
}