public class ForLoop{
	public static void main(String[] args){
		int[] a1 = new int[20];
		int r = 0;
		
		for(int i=0; i<a1.length; i++){
			r = r + 1;
		System.out.println(r);
		}
	}
}