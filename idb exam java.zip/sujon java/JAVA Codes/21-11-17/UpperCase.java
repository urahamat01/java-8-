public class UpperCase{
	public static void main(String[] args){
		String s1 = "Bangladesh Dhaka Khulna";
		String s2 = s1.toUpperCase();
		System.out.println(s2);
	}
}