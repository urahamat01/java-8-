public class Ch{
	public static void main(String[] args){
		String s1 = "Bangladesh";
		char c1 = s1.charAt(1);
		System.out.println(c1);
	}
}