public class LowerCase{
	public static void main(String[] args){
		String s1 = "Bangladesh Dhaka Khulna";
		String s2 = s1.toLowerCase();
		System.out.println(s2);
	}
}