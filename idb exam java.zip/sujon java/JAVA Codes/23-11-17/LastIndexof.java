public class LastIndexof{
	public static void main(String[] args){
		String s1 = "Bangladesh";
		int x = s1.lastIndexOf('a');
		System.out.println(x);
	}
}