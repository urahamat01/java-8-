public class Student{
	public static void main(String[] agrs){
		System.out.println("ID : 1240090.");
		System.out.println("Name : Monirul Islam.");
		System.out.println("Round : 34.");
		System.out.println("E-mail : monirul@gmail.com.");
	}
}