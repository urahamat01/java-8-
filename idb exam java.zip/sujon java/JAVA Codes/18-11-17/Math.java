public class Math{
	public static int x = 5;
	public static int y = 5;
	public static int z = 0;
	public static void main(String[] agrs){
		z = x + y;
		System.out.println("Result = " + z);
	}
}