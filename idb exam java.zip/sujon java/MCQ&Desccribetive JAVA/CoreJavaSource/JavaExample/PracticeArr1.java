import java.util.Scanner;
public class PracticeArr1{
	
	public static void main(String[] args){
		int[] p = new int[5];
		
		Scanner sc = new Scanner(System.in);
			System.out.print("Enter first value ");
			p[0] = sc.nextInt(); 
			
			System.out.print("Enter second value ");
			p[1] = sc.nextInt(); 
			
			System.out.print("Enter third value ");
			p[2] = sc.nextInt(); 
			
			System.out.print("Enter fourth value ");
			p[3] = sc.nextInt(); 
			
			System.out.print("Enter fivth value ");
			p[4] = sc.nextInt(); 
			
			
			
		System.out.println(p[0]+","+p[1]+","+p[2]+","+p[3]+","+p[4]);
		
	
	}
	
}