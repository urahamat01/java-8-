import java.util.*;
public class q2{
public static void main(String[]args){
Scanner sc=new Scanner(System.in);
   
  String s=sc.nextInt();
System.out.println("Input the result is");

   if(s=='A'){
             System.out.println("The result is Excellint");



       }else if(s=='B'){

          System.out.println("The result is Good");


         }else if(s=='c'){
          System.out.println("The result is Pass");


          }else if(s=='f') {

          System.out.println("The result is Failuar");



           }

    }




}